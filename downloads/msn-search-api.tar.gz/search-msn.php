<?php 
# Change the following if you move the files from the default locations.
include ($_SERVER['DOCUMENT_ROOT'] . "/include/MSNSearch.php");
define("SEARCH_URL","/search-msn.php");

# Ensure there are valid starting values
$start = isset($_GET['start']) ? intval($_GET['start']) : 1;
$q = isset($_GET['q']) ? $_GET['q'] : "";
if ($start < 1)
	$start = 1;
?>
<!DOCTYPE html 
     PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
     "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>MSN Search using API</title>
<meta name="robots" content="noindex,nofollow,noarchive" />
<style type="text/css">
html,body{font-family:sans-serif;background:#CEE;}
dl.search_results dt{font-size:115%;margin-top:1em;}
dl.search_results dd{font-family:serif;}
input.search_submit {font-size:90%;color:#FFF;background:#ADE;width:auto;}
input.search_input{color:#000;background:#DAE;border:1px solid #0F0;}
p.search_header, p.search_nav {background:#DEF;border:1px solid #000;text-align:center;}
span.search_url {font-size:90%;color:#999;font-family:monospace;}
#form_top,#form_bottom {border:2px dashed #F33;margin:.25em auto 0;padding:.35em;}
#form_top td, #form_bottom td {text-align:center;padding:.25em;}
</style>
</head>

<body>
<h1>MSN API Search</h1>
<?php
print searchform($q,"form_top",SEARCH_URL);
if (strlen($q) > 1) {
	$msnsearch = new MSNSearch('INSERTAPIKEYHERE');
	$sresult = false;
	$msnsearch->setQuery($q);
	$msnsearch->setPage($start);
	$sresult = $msnsearch->search();
	if (($sresult === true) && ($msnsearch->totalRecords > 0)) {
		print $msnsearch->search_header($q);
		print $msnsearch->search_results();
		print $msnsearch->search_navagation($q);
		print searchform($q,"form_bottom",SEARCH_URL);
	} else 
		print "<p>Sorry, no results found for <b>$q</b>.</p>\n";

} else { ?>
<p>Enter the terms you wish to search for above.</p>
<?php } ?>
<p><a href='http://search.msn.com/developer'>powered by MSN Search</a></p>
</body>
</html>
