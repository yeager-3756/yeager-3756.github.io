<?php 
##############################################################################
#     MSN Search API Class for PHP                                           #
#     Copyright (C) 2006  Darrin Yeager                                      #
#     All rights reserved.                                                   #
#     http://www.dyeager.org                                                 #
#                                                                            #
#	September 2006                                                            #
#                                                                            #
# Redistribution and use in source and binary forms, with or without         #
# modification, are permitted provided that the following conditions         #
# are met:                                                                   #
#                                                                            #
#   1. Redistributions of source code must retain the above copyright        #
#      notice, this list of conditions and the following disclaimer.         #
#                                                                            #
#   2. Redistributions in binary form must reproduce the above copyright     #
#      notice, this list of conditions and the following disclaimer in the   #
#      documentation and/or other materials provided with the distribution.  #
#                                                                            #
#   3. Redistributions of modified versions must carry prominent notices     #
#      stating that you changed the files and the date of any change.        #
#                                                                            #
#   4. Neither the name of Darrin Yeager nor the names of any contributors   #
#      may be used to endorse or promote products derived from this software #
#      without specific prior written permission.                            #
#                                                                            #
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS        #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT          #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR      # 
# A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT       #
# OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,      #
# SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED   #
# TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR     #
# PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF     #
# LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING       #
# NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS         #
# SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.               #
#                                                                            #
##############################################################################


# uncomment and define for your email address to get email of script errors.
#define("MAILTO","webmaster@yourdomain.com");

include ($_SERVER['DOCUMENT_ROOT'] .'/include/nusoapx.php');

# This function is outside the class so it can be called without creating
# a class instance.
function searchform($query, $id, $search_url="/search.php") {
	$x = $id . "_input";
	$r = "<form style='border:none;' method='get' action='" . $search_url . "'>\n";
	$r .= " <table id='$id'>\n";
	$r .= "  <tr><td><input type='text' name='q' size='30' id='$x' class='search_input' value=\"" . htmlspecialchars($query,ENT_NOQUOTES,"UTF-8") . "\" /></td></tr>\n";
	$r .= "  <tr><td><input type='submit' value='search' class='search_submit' /></td></tr>\n";
	$r .= " </table>\n";
	$r .= "</form>\n";
	return  $r;
}

class MSNSearch {
	var $appID;
	var $errorMessage;
	var $page;
	var $query;
	var $recordsPerPage;
	var $results;
	var $safeSearch;
	var $totalPages;
	var $totalRecords;

	function MSNSearch($appID) {
		$this->appID = $appID;
		$this->errorMessage = "";
		$this->page = 1;
		$this->query = "";
		$this->recordsPerPage = 10;
		$this->safeSearch = true;
		$this->totalPages = 0;
		$this->totalRecords = 0;
	}

	function setPage($page) {	
		$this->page = ($page < 1) ? 1 : $page;
	}
	
	function setQuery($query) {
		$this->query = $query;
	}

	function search_header($query) {
		$r = "<p class='search_header'>Results Page <b>" . $this->page . "</b>";
		$r .= " of <b>" . $this->totalPages . "</b>" . ($this->totalPages == 1 ? " Page " : " Pages ");
		$r .= " for <b>" . $query . "</b></p>\n";
		return $r;
	}

	function search_navagation($q) {
		if ($this->totalRecords <= $this->recordsPerPage)
			return "";
		$query = urlencode($q);
		$query = htmlspecialchars($query,ENT_NOQUOTES,"UTF-8");
		$r = "<p class='search_nav'>";
		if ($this->page > 1) 
			$r .= " <b><a href='" . SEARCH_URL . "?q=" . $query . "&amp;start=" . ($this->page - 1) . "'>previous page</a></b> | ";
		else 
			$r .= " previous page | ";
		if ($this->totalRecords > ($this->page * $this->recordsPerPage)) 
			$r .= " <b><a href='" . SEARCH_URL . "?q=" . $query . "&amp;start=" . ($this->page + 1) . "'>next page</a></b> ";
		else
			$r .= " next page ";
		$r .= "</p>\n";
		return $r;
	}

	function search_results() {
		$r = "<dl class='search_results'>\n";
		foreach ($this->results as $item) {
			$r .= "<dt><a href='" . htmlspecialchars($item['url'],ENT_NOQUOTES,"UTF-8") . "'>" . $item['title'] . "</a></dt>\n";
			$r .= "<dd>" . htmlspecialchars($item['snippet'],ENT_NOQUOTES,"UTF-8");
			$r .= (strlen($item['snippet']) > 5 ? "<br />\n" : "");
			$r .= "<span class='search_url'>" . htmlspecialchars(str_replace("http://","",$item['url']),ENT_NOQUOTES,"UTF-8") . "</span>\n";
			$r .= "</dd>\n";
		}
		$r .= "</dl>\n";
		return $r;
	}

	function search() {
		$this->errorMessage = "";
		$this->totalPages = 0;
		$this->totalRecords = 0;
		$this->results = array();
		$parameters = array(
			'AppID' => $this->appID,
			'Query' => $this->query,
			'CultureInfo' => 'en-US',
			'SafeSearch' => ($this->safeSearch ? 'Moderate' : 'Off'), # Could be Strict here as well
			'Requests' => array (
				'SourceRequest' => array (
					'Source' => 'Web',
					'Offset' => ($this->page - 1) * $this->recordsPerPage,
					'Count' => $this->recordsPerPage,
					'ResultFields' => 'All'
				)
			)
		);
		$soapClient = new soapclientx("http://soap.search.msn.com/webservices.asmx");
		$retry_count = 0;
		$soapResult = false;
		while( !$soapResult && $retry_count < 3) {  # Try request 3 times before failing
			$soapResult = $soapClient->call('Search', array ('Request' => $parameters), "http://schemas.microsoft.com/MSNSearch/2005/09/fex" );
			$retry_count++;
		}
		if ($soapClient->getError()) {
			$this->errorMessage = $soapClient->getError();
			$msg = "Search error:\n" . $this->errorMessage . "\n";
			$msg .= "Query: " . $this->query . "\n";
			$msg .= "Date: " . date('D M d Y h:i:s');
			if (defined("MAILTO"))
				@mail(MAILTO,"** Search ERROR ***", $msg);
			return false;
		}
		$this->totalRecords = $soapResult['Responses']['SourceResponse']['Total'];
		$this->totalPages = ceil($this->totalRecords / $this->recordsPerPage);
		if (($this->totalRecords > 0) && (is_array($soapResult['Responses']['SourceResponse']['Results']['Result']))) {
			foreach ($soapResult['Responses']['SourceResponse']['Results']['Result'] as $item) {
				$this->results[] = array (
					'url' => $item['Url'],
					'displayurl' => $item['DisplayUrl'],
					'cacheurl' => isset($item['CacheUrl']) ? $item['CacheUrl'] : "",
					'title' => isset($item['Title']) && trim($item['Title']) != '' ? $item['Title'] : $item['DisplayUrl'],
					'snippet' => isset($item['Description']) ? $item['Description'] : ""
				);
			}
		}
		return true;
	}
}
?>