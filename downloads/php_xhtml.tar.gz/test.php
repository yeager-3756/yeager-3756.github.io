<?php
# to use XHTML 1.0 Strict DTD
define("DOCTYPE","strict");

# to use XHTML 1.1 MathML DTD
#define("DOCTYPE","math");

# if DOCTYPE is not defined, the transitional
# XHTML 1.0 DTD will be used.
require_once("include-mime.php");
?>
<title>Test Page</title>
</head>
<body>

<h1>Test Page</h1>

<h2>Server Variables</h2>
<pre>
<?php
foreach ($_SERVER as $key => $value)
  print "$key: $value\n";
?>
</pre>


</body>
</html>
